/*
# Create contact_messages table

1. Purpose
   Stores messages submitted through the portfolio site's contact form so
   the site owner can follow up with visitors who reach out.

2. New Tables
   - `contact_messages`
     - `id` (uuid, primary key) - unique identifier for the message
     - `name` (text, not null) - sender's name
     - `email` (text, not null) - sender's email address, for replying
     - `message` (text, not null) - message body
     - `created_at` (timestamptz, default now()) - submission time

3. Security
   - Enable Row Level Security on `contact_messages`.
   - Allow anonymous and authenticated visitors to INSERT messages only
     (this is a public contact form with no sign-in, so anon must be able
     to submit).
   - No SELECT/UPDATE/DELETE policies are added, so submitted messages
     cannot be read, changed, or removed through the public API - only
     the project owner can view them via the Supabase dashboard.
*/

CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_contact_messages" ON contact_messages;
CREATE POLICY "anon_insert_contact_messages" ON contact_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);
