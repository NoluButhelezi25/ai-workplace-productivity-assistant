export const profile = {
  name: 'Noluthando Buthelezi',
  role: 'Aspiring Software Developer',
  tagline:
    'React, UI/UX | Building responsive web apps — based in Germiston, South Africa.',
  location: 'Germiston, South Africa',
  email: 'noluthandobuth12@gmail.com',
  linkedin: 'https://www.linkedin.com/in/noluthando-buthelezi',
  github: 'https://github.com/noluthando-buthelezi',
  resumeUrl: '/resume.pdf',
};

export const about = {
  paragraphs: [
    "With a background in retail and a drive to grow in technology, I'm now pursuing an AI Skills Programme. I've gained experience in customer interaction and operations, and I'm now developing technical skills in React, AI and Data Analysis.",
    "I'm motivated to transition into tech and use AI to create solutions that improve experiences for people and businesses.",
  ],
  highlights: [
    { label: 'Career transition', value: 'Retail → Tech' },
    { label: 'Focus areas', value: 'React, AI, Data' },
    { label: 'Based in', value: 'Germiston, ZA' },
  ],
};

export type Skill = { name: string; level: number };

export const technicalSkills: Skill[] = [
  { name: 'Git & GitHub', level: 75 },
  { name: 'Data Analysis & Visualisation', level: 80 },
  { name: 'Machine Learning Fundamentals', level: 70 },
  { name: 'React', level: 65 },
  { name: 'UI/UX Design', level: 70 },
];

export const softSkills: string[] = [
  'Customer interaction',
  'Operations & teamwork',
  'Adaptability & learning',
  'Attention to detail',
  'Problem-solving',
  'Clear communication',
];

export type Project = {
  title: string;
  description: string;
  technologies: string[];
  liveUrl?: string;
  codeUrl?: string;
};

export const projects: Project[] = [
  {
    title: 'Professional Portfolio Website',
    description:
      'A course project from the AI Skills Programme where I created a professional website portfolio to showcase my skills, background, and projects — built to be fully responsive across all screen sizes.',
    technologies: ['React', 'Tailwind CSS', 'Responsive Design'],
    liveUrl: '#',
    codeUrl: '#',
  },
  {
    title: 'Retail Sales Analysis',
    description:
      'An Excel project from my retail experience where I analysed 6 months of retail sales data to identify footcount, peak shopping days, and slow periods — giving the team a clearer picture of store traffic patterns.',
    technologies: ['Microsoft Excel', 'Data Analysis'],
    liveUrl: '#',
    codeUrl: '#',
  },
  {
    title: 'Customer Satisfaction (CSAT) Tracker',
    description:
      'A customer satisfaction score tracker where I used Excel to record CSAT scores weekly and built a dashboard showing which days had the best or worst service — helping spot trends and improve customer experience.',
    technologies: ['Microsoft Excel', 'Dashboards', 'Data Visualization'],
    liveUrl: '#',
    codeUrl: '#',
  },
];

export type EducationItem = {
  school: string;
  degree: string;
  period: string;
  description?: string;
};

export const education: EducationItem[] = [
  {
    school: 'Kwa-Dukathole Comprehensive School',
    degree: 'Matric (National Senior Certificate)',
    period: '2017',
    description: 'Passed matric in 2017.',
  },
];

export type Certification = {
  name: string;
  issuer: string;
  year: string;
};

export const certifications: Certification[] = [
  { name: 'Perform First Aid — Level', issuer: 'Hesscon', year: '2024' },
  { name: 'Customer Care NQF Level 3', issuer: 'MSC Education Group', year: '2026' },
];
