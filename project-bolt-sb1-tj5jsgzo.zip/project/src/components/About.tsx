import { about } from '@/data/portfolio';

export default function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <span className="text-sm font-semibold text-primary-600 uppercase tracking-wider">
            About Me
          </span>
          <h2 className="font-display font-bold text-3xl lg:text-4xl text-slate-900 mt-3">
            Building software that people actually enjoy using
          </h2>
        </div>

        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-16">
          <div className="space-y-5">
            {about.paragraphs.map((paragraph, index) => (
              <p key={index} className="text-slate-600 leading-relaxed text-lg">
                {paragraph}
              </p>
            ))}
          </div>

          <div className="grid grid-cols-3 lg:grid-cols-1 gap-4">
            {about.highlights.map((item) => (
              <div
                key={item.label}
                className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center lg:text-left hover:border-primary-200 hover:bg-primary-50/40 transition-colors"
              >
                <p className="font-display font-bold text-3xl lg:text-4xl text-primary-700">
                  {item.value}
                </p>
                <p className="text-sm text-slate-500 mt-1">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
