import { FormEvent, useState } from 'react';
import { CheckCircle2, Linkedin, Loader2, Mail, MapPin, TriangleAlert } from 'lucide-react';
import { profile } from '@/data/portfolio';
import { supabase } from '@/lib/supabase';

type Status = 'idle' | 'submitting' | 'success' | 'error';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<Status>('idle');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('submitting');

    const { error } = await supabase.from('contact_messages').insert({
      name: name.trim(),
      email: email.trim(),
      message: message.trim(),
    });

    if (error) {
      setStatus('error');
      return;
    }

    setStatus('success');
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <section id="contact" className="py-24 lg:py-32 bg-slate-900 relative overflow-hidden">
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-primary-600/20 rounded-full blur-3xl" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-accent-600/20 rounded-full blur-3xl" />

      <div className="relative max-w-6xl mx-auto px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <span className="text-sm font-semibold text-accent-400 uppercase tracking-wider">
            Contact
          </span>
          <h2 className="font-display font-bold text-3xl lg:text-4xl text-white mt-3">
            Let's build something together
          </h2>
          <p className="text-slate-400 mt-4 text-lg leading-relaxed">
            Have a project in mind or just want to say hello? My inbox is always open.
          </p>
        </div>

        <div className="grid lg:grid-cols-[0.8fr_1.2fr] gap-12">
          <div className="space-y-5">
            <a
              href={`mailto:${profile.email}`}
              className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-colors"
            >
              <span className="flex-shrink-0 w-11 h-11 rounded-xl bg-primary-500/20 text-primary-400 flex items-center justify-center">
                <Mail size={18} />
              </span>
              <div>
                <p className="text-xs text-slate-400">Email</p>
                <p className="text-sm font-medium text-white">{profile.email}</p>
              </div>
            </a>

            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-colors"
            >
              <span className="flex-shrink-0 w-11 h-11 rounded-xl bg-accent-500/20 text-accent-400 flex items-center justify-center">
                <Linkedin size={18} />
              </span>
              <div>
                <p className="text-xs text-slate-400">LinkedIn</p>
                <p className="text-sm font-medium text-white">Connect with me</p>
              </div>
            </a>

            <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-2xl p-5">
              <span className="flex-shrink-0 w-11 h-11 rounded-xl bg-white/10 text-slate-300 flex items-center justify-center">
                <MapPin size={18} />
              </span>
              <div>
                <p className="text-xs text-slate-400">Location</p>
                <p className="text-sm font-medium text-white">{profile.location}</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 space-y-5">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Your Name
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-shadow"
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Your Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-shadow"
                  placeholder="jane@example.com"
                />
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1.5">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-shadow resize-none"
                placeholder="Tell me a bit about what you have in mind..."
              />
            </div>

            <button
              type="submit"
              disabled={status === 'submitting'}
              className="w-full inline-flex items-center justify-center gap-2 bg-slate-900 text-white font-medium px-6 py-3.5 rounded-xl hover:bg-primary-700 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {status === 'submitting' ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  Sending...
                </>
              ) : (
                'Send Message'
              )}
            </button>

            {status === 'success' && (
              <p className="flex items-center gap-2 text-sm text-emerald-600 font-medium">
                <CheckCircle2 size={16} />
                Thanks for reaching out — I'll get back to you soon.
              </p>
            )}
            {status === 'error' && (
              <p className="flex items-center gap-2 text-sm text-red-600 font-medium">
                <TriangleAlert size={16} />
                Something went wrong sending your message. Please try again.
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
