import { ArrowDown, Download, Github, Linkedin, Mail } from 'lucide-react';
import { profile } from '@/data/portfolio';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden bg-gradient-to-b from-slate-50 to-white"
    >
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-24 -right-24 w-[32rem] h-[32rem] bg-primary-100 rounded-full blur-3xl opacity-60" />
        <div className="absolute top-1/3 -left-32 w-96 h-96 bg-accent-100 rounded-full blur-3xl opacity-50" />
      </div>

      <div className="relative max-w-6xl mx-auto px-6 lg:px-8 w-full grid lg:grid-cols-[1.15fr_0.85fr] gap-16 items-center">
        <div className="animate-fade-in-up">
          <p className="inline-flex items-center gap-2 text-sm font-medium text-primary-700 bg-primary-50 border border-primary-100 rounded-full px-4 py-1.5 mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            Available for new opportunities
          </p>

          <h1 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl text-slate-900 leading-[1.1] tracking-tight mb-6">
            Hi, I'm {profile.name}
            <span className="block mt-2 text-primary-600">{profile.role}</span>
          </h1>

          <p className="text-lg text-slate-600 leading-relaxed max-w-xl mb-10">
            {profile.tagline}
          </p>

          <div className="flex flex-wrap items-center gap-4 mb-10">
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 bg-slate-900 text-white font-medium px-6 py-3.5 rounded-full hover:bg-primary-700 transition-all hover:shadow-lg hover:-translate-y-0.5"
            >
              <Mail size={18} />
              Get in touch
            </a>
            <a
              href={profile.resumeUrl}
              download
              className="inline-flex items-center gap-2 bg-white text-slate-900 font-medium px-6 py-3.5 rounded-full border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all hover:-translate-y-0.5"
            >
              <Download size={18} />
              Download CV
            </a>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="w-11 h-11 flex items-center justify-center rounded-full border border-slate-200 text-slate-600 hover:text-primary-700 hover:border-primary-300 hover:bg-primary-50 transition-colors"
            >
              <Linkedin size={19} />
            </a>
            <a
              href={profile.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="w-11 h-11 flex items-center justify-center rounded-full border border-slate-200 text-slate-600 hover:text-primary-700 hover:border-primary-300 hover:bg-primary-50 transition-colors"
            >
              <Github size={19} />
            </a>
            <a
              href={`mailto:${profile.email}`}
              aria-label="Email"
              className="w-11 h-11 flex items-center justify-center rounded-full border border-slate-200 text-slate-600 hover:text-primary-700 hover:border-primary-300 hover:bg-primary-50 transition-colors"
            >
              <Mail size={19} />
            </a>
          </div>
        </div>

        <div className="hidden lg:flex justify-center animate-fade-in-up" style={{ animationDelay: '150ms' }}>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary-500 to-accent-400 rounded-[2.5rem] rotate-6 opacity-90 animate-float" />
            <div className="relative w-72 h-72 rounded-[2.5rem] bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center shadow-2xl">
              <span className="font-display font-bold text-7xl text-white/90">
                {profile.name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')}
              </span>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
        aria-label="Scroll to about section"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-slate-400 hover:text-primary-600 transition-colors animate-bounce"
      >
        <ArrowDown size={24} />
      </button>
    </section>
  );
}
