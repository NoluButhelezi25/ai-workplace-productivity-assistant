import { useEffect, useRef, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { softSkills, technicalSkills } from '@/data/portfolio';

export default function Skills() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="skills" className="py-24 lg:py-32 bg-slate-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-8" ref={sectionRef}>
        <div className="max-w-2xl mb-14">
          <span className="text-sm font-semibold text-primary-600 uppercase tracking-wider">
            Skills
          </span>
          <h2 className="font-display font-bold text-3xl lg:text-4xl text-slate-900 mt-3">
            What I bring to a team
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h3 className="font-display font-semibold text-xl text-slate-900 mb-6">
              Technical Skills
            </h3>
            <div className="space-y-5">
              {technicalSkills.map((skill) => (
                <div key={skill.name}>
                  <div className="flex justify-between items-baseline mb-1.5">
                    <span className="text-sm font-medium text-slate-700">{skill.name}</span>
                    <span className="text-xs text-slate-400">{skill.level}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary-500 to-accent-500 transition-all duration-1000 ease-out"
                      style={{ width: isVisible ? `${skill.level}%` : '0%' }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-display font-semibold text-xl text-slate-900 mb-6">
              Soft Skills
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {softSkills.map((skill) => (
                <div
                  key={skill}
                  className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-3.5 hover:border-primary-200 hover:shadow-sm transition-all"
                >
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-accent-50 text-accent-600 flex items-center justify-center">
                    <Sparkles size={15} />
                  </span>
                  <span className="text-sm font-medium text-slate-700">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
