import { Award, GraduationCap } from 'lucide-react';
import { certifications, education } from '@/data/portfolio';

export default function Education() {
  return (
    <section id="education" className="py-24 lg:py-32 bg-slate-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <span className="text-sm font-semibold text-primary-600 uppercase tracking-wider">
            Education &amp; Certifications
          </span>
          <h2 className="font-display font-bold text-3xl lg:text-4xl text-slate-900 mt-3">
            Academic background and credentials
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h3 className="font-display font-semibold text-xl text-slate-900 mb-6 flex items-center gap-2">
              <GraduationCap size={22} className="text-primary-600" />
              Education
            </h3>
            <div className="space-y-4">
              {education.map((item) => (
                <div
                  key={item.school}
                  className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-primary-200 hover:shadow-sm transition-all"
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2 mb-1">
                    <h4 className="font-semibold text-slate-900">{item.school}</h4>
                    <span className="text-xs font-medium text-slate-400">{item.period}</span>
                  </div>
                  <p className="text-primary-700 font-medium text-sm mb-2">{item.degree}</p>
                  {item.description && (
                    <p className="text-sm text-slate-600 leading-relaxed">{item.description}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-display font-semibold text-xl text-slate-900 mb-6 flex items-center gap-2">
              <Award size={22} className="text-accent-600" />
              Certifications
            </h3>
            <div className="space-y-4">
              {certifications.map((cert) => (
                <div
                  key={cert.name}
                  className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-accent-200 hover:shadow-sm transition-all flex items-start gap-4"
                >
                  <span className="flex-shrink-0 w-10 h-10 rounded-xl bg-accent-50 text-accent-600 flex items-center justify-center">
                    <Award size={17} />
                  </span>
                  <div>
                    <h4 className="font-semibold text-slate-900 text-sm leading-snug">
                      {cert.name}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      {cert.issuer} &middot; {cert.year}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
